'''
Plant
name, health, damage
attack(zombie), take_damage(amount)

Zombie
name, health, damage, distance
move(), attack(plant), take_damage(amount)
'''

from ast import If


class Plant:
    def __init__(self, name, health, damage, attack_name):
        self.name = name
        self.health = health
        self.damage = damage
        self.attack_name = attack_name

    def attack(self, zombie):
        zombie.take_damage(self.damage)

    def take_damage(self, amount):
        self.health -= amount



class Zombie:
    def __init__(self, name, health, damage, distance):
        self.name = name
        self.health = health
        self.damage = damage
        self.distance = distance 

    def move(self):
        self.distance -= 1

    def attack(self, plant):
        plant.take_damage(self.damage)

    def take_damage(self, amount):
        self.health -= amount

Plant1 = Plant("Novaeangliae", 200, 10, "Mega Splash")
Plant2 = Plant("Faerianthesis", 150, 20, "Rose Thorn")
Zombie1 = Zombie("Zomby", 100, 45, 5)

while True:
    if Zombie1.distance > 0:
        print(f"=={Zombie1.name} is {Zombie1.distance} units away from the plants.==")
        Zombie1.move()
    
    if Zombie1.distance == 0:
        if Plant1.health > 0:
            Zombie1.attack(Plant1)
            print(f"{Zombie1.name} attacked {Plant1.name}. {Plant1.name}'s health is now {Plant1.health}.")
        elif Plant2.health > 0:
            Zombie1.attack(Plant2)
            print(f"{Zombie1.name} attacked {Plant2.name}. {Plant2.name}'s health is now {Plant2.health}.\n")
        elif Plant1.health <= 0 or Plant2.health <= 0:
            print("The plants have been defeated!")
            break


    
    if Plant1.health > 0:
        Plant1.attack(Zombie1)
        print(f"{Plant1.name} used {Plant1.attack_name} and dealt {Plant1.damage} damage. {Zombie1.name}'s health is now {Zombie1.health}.")
    
    if Plant2.health > 0:
        Plant2.attack(Zombie1)
        print(f"{Plant2.name} used {Plant2.attack_name} and dealt {Plant2.damage} damage. {Zombie1.name}'s health is now {Zombie1.health}.\n")

    if Zombie1.health <= 0:
        print(f"{Zombie1.name} has been defeated!")
        break




